import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tcc_app/Telas/selecionarItem.dart';
import 'package:tcc_app/repositorio/personagem_repositorio.dart';
import 'package:tcc_app/wigtes/AdicionarItem.dart';
import 'package:tcc_app/wigtes/radioGroup.dart';

class AdicionarPersonagem extends StatelessWidget {
  AdicionarPersonagem({super.key});

  final ScrollController _scrollController = ScrollController();

  void _entrarNaPaginaDeRaca(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const Selecionaritem()),
    );
  }

  Map<String, VoidCallback> lista(BuildContext context) => {
    "Raça": () => _entrarNaPaginaDeRaca(context),
    "Classe": () => _entrarNaPaginaDeRaca(context),
    "Atributos": () => _entrarNaPaginaDeRaca(context),
    "Equipamentos": () => _entrarNaPaginaDeRaca(context),
    "Habilidades": () => _entrarNaPaginaDeRaca(context),
  };

  @override
  Widget build(BuildContext context) {
    final personagem = context.watch<PersonagemRepositorio>();

    final itens = lista(context);

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ListView(
          controller: _scrollController,
          children: [
            for (var item in itens.entries) ...[
              Adicionaritem(onTap: item.value, titulo: item.key),
              const SizedBox(height: 10),
            ],
            Radiogroup(
              initialValue: 'Masculino',
              onChanged: (v) {
                print('selecionado: $v');
              },
            ),
            ElevatedButton(
              onPressed: () async {
                await personagem.insert('personagens', {'nome': 'Goku', 'pv': 100});

                final nome = await personagem.ultimoNome();

                showModalBottomSheet(
                  context: context,
                  builder: (context) => Container(
                    padding: const EdgeInsets.all(16),
                    child: Text(nome ?? 'Sem nome'),
                  ),
                );
              },
              child: const Text("Salvar"),
            ),
          ],
        ),
      ),
    );
  }
}
